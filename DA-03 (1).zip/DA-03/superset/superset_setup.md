# Superset setup
1. `docker compose up -d`, then create the admin user: `docker exec -it superset superset fab create-admin --username admin --firstname A --lastname A --email a@a.com --password admin && docker exec superset superset db upgrade && docker exec superset superset init`
2. Open http://localhost:8088, Settings > Database Connections > add `postgresql://tower:tower@postgres:5432/tower`.
3. Add datasets: `v_stockout_daily`, `v_supplier_perf`, `sku_status`, `shipments`, `inventory_hourly`.
4. Charts: stock-out % (line, v_stockout_daily), supplier on-time % (bar, v_supplier_perf), cover days by SKU (bar, sku_status, colour by status), shipment delay (histogram, shipments).
5. What-if panel: add a dashboard Native Filter on `supplier` plus a Jinja-templated dataset: `SELECT sku, supplier, cover_days, wait_days + CASE WHEN supplier = '{{ filter_values("supplier")[0] }}' THEN {{ url_param("delay", 7) }} ELSE 0 END AS new_wait FROM sku_status` (a SKU is at risk when cover_days < new_wait). The browser dashboard.html provides the same what-if interactively.
