# DA-03 Retail and Supply Chain Control Tower
Near real-time view of inventory, deliveries and suppliers that warns about problems before they hurt sales. Data is simulated (hourly feeds, 45 days, 12 SKUs, 6 suppliers) with two injected incidents so detection can be verified: a SKU03 demand spike (last 3 days) and a Delta Traders (S4) delivery-delay incident (last 20 days).

## Run offline (no Docker needed)
```
pip install -r requirements.txt
python pipeline.py          # writes data/*.csv, docs/metrics.json, data/alerts.json, dashboard.html
python -m pytest tests      # 8 tests
```
Open `dashboard.html` in a browser: Overview, Inventory, Suppliers, Forecast, Anomalies, What-if, Alerts.

## Full stack (Postgres + Airflow + Superset)
```
docker compose up -d        # see superset/superset_setup.md for dashboards
```
The Airflow DAG `control_tower_hourly` (dags/) runs hourly: generate feed -> load Postgres -> KPIs, anomalies, Prophet forecast, alerts, dashboard rebuild.

## Research paper
`DA-03_Research_Paper_and_Source.pdf` holds the paper and full source listings; rebuild with `python build_paper.py`.

## Requirement map
| Spec step | Where |
|---|---|
| 1 Data in PostgreSQL | simulate() in pipeline.py, schema.sql, load_to_postgres.py |
| 2 Airflow hourly refresh | dags/control_tower_dag.py (@hourly) |
| 3 KPIs: stock-out rate, on-time delivery, supplier lead time, days of inventory | kpis() |
| 4 Anomaly detection | anomalies(): rolling z-score (demand), z-score + Isolation Forest (shipment delays) |
| 5 Prophet forecast vs stock | forecast(): 14-day forecast, cover days vs replenishment wait |
| 6 Superset dashboards + what-if | superset/superset_setup.md, views in schema.sql; what-if also in dashboard.html |
| 7 Slack/email alerts | build_alerts(), dispatch() (SLACK_WEBHOOK_URL, SMTP_HOST + ALERT_TO; otherwise dry-run log) |

## Verification status
Verified here: pipeline, tests, dashboard JavaScript (smoke-tested against a stubbed DOM). Written but not executed in the build environment: docker-compose.yml, Airflow DAG (syntax-checked only), load_to_postgres.py, Superset steps, real Slack/SMTP sending. Run them once on your machine before recording the demo.
