"""Load data/*.csv into PostgreSQL (DATABASE_URL, default postgresql://tower:tower@localhost:5432/tower)."""
import os, psycopg2
ROOT = os.path.dirname(os.path.abspath(__file__))
TABLES = {"sku_master": "sku_master.csv", "inventory_hourly": "inventory_hourly.csv", "shipments": "shipments.csv", "sku_status": "sku_status.csv"}

def load(url=None):
    con = psycopg2.connect(url or os.getenv("DATABASE_URL", "postgresql://tower:tower@localhost:5432/tower"))
    with con, con.cursor() as cur:
        cur.execute(open(f"{ROOT}/schema.sql").read())
        for t, f in TABLES.items():
            if os.path.exists(f"{ROOT}/data/{f}"):
                cur.execute(f"TRUNCATE {t}")
                with open(f"{ROOT}/data/{f}") as fh:
                    cur.copy_expert(f"COPY {t} FROM STDIN WITH CSV HEADER", fh)
    con.close()

if __name__ == "__main__":
    load(); print("loaded")
