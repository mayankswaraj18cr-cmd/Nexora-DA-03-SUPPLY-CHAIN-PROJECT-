CREATE TABLE IF NOT EXISTS sku_master (sku TEXT PRIMARY KEY, name TEXT, supplier TEXT, base_daily INT);
CREATE TABLE IF NOT EXISTS inventory_hourly (ts TIMESTAMP, sku TEXT, stock INT, demand INT, unmet INT);
CREATE TABLE IF NOT EXISTS shipments (shipment_id TEXT PRIMARY KEY, sku TEXT, supplier TEXT, order_ts TIMESTAMP, promised_days INT, actual_days NUMERIC(6,2),
  qty INT, delivered SMALLINT, eta_days NUMERIC(6,2), delay_days NUMERIC(6,2), on_time SMALLINT);
CREATE TABLE IF NOT EXISTS sku_status (sku TEXT, name TEXT, supplier TEXT, stock INT, fc_daily NUMERIC, cover_days NUMERIC, lead_days INT,
  wait_days NUMERIC, in_transit SMALLINT, mape NUMERIC, status TEXT);
CREATE INDEX IF NOT EXISTS ix_inv ON inventory_hourly (sku, ts);
CREATE OR REPLACE VIEW v_stockout_daily AS
  SELECT date_trunc('day', ts)::date AS day, 100.0 * avg((stock = 0)::int) AS stockout_pct, sum(demand) AS demand FROM inventory_hourly GROUP BY 1;
CREATE OR REPLACE VIEW v_supplier_perf AS
  SELECT supplier, count(*) FILTER (WHERE delivered = 1) AS delivered, avg(actual_days) FILTER (WHERE delivered = 1) AS avg_lead_days,
         100.0 * avg(on_time) FILTER (WHERE delivered = 1) AS on_time_pct FROM shipments GROUP BY supplier;
