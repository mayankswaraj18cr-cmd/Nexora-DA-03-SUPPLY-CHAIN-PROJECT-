# Test results
```
tests/test_pipeline.py::test_deterministic_and_shape PASSED              [ 12%]
tests/test_pipeline.py::test_stock_never_negative_and_unmet_consistent PASSED [ 25%]
tests/test_pipeline.py::test_on_time_definition PASSED                   [ 37%]
tests/test_pipeline.py::test_kpis_in_range PASSED                        [ 50%]
tests/test_pipeline.py::test_detects_injected_demand_spike PASSED        [ 62%]
tests/test_pipeline.py::test_detects_injected_supplier_delay PASSED      [ 75%]
tests/test_pipeline.py::test_status_and_whatif_logic PASSED              [ 87%]
tests/test_pipeline.py::test_forecast_accuracy_and_alerts PASSED         [100%]
============================== 8 passed in 6.06s ===============================
```
Pipeline output (docs/metrics.json): 7d stock-out 7.79 %; on-time 82.4 %; avg lead 4.14 d; mean forecast MAPE 11.3 %; SKU status {'Critical': 2, 'Watch': 3, 'OK': 7} ; anomalies {'demand_spikes': 5, 'delay_outliers': 4}
Both injected incidents (SKU03 demand spike, supplier S4 delays) are detected; Prophet backtest = fit on first 38 days, score last 7.
