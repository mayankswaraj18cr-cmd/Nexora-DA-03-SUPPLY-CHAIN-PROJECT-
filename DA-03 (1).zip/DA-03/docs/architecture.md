# Architecture
```
 simulate() hourly feeds ──> data/*.csv ──> load_to_postgres.py ──> PostgreSQL ──> Superset dashboards
        │ (inventory, shipments, SKU master)        ▲ views: v_stockout_daily, v_supplier_perf
        ▼                                           │
 Airflow DAG (@hourly): generate_feed ─> load_postgres ─> analyze_alert_publish
                                                         ├─ kpis()        stock-out, on-time, lead time, days of inventory
                                                         ├─ anomalies()   z-score, Isolation Forest
                                                         ├─ forecast()    Prophet 14d + cover vs wait
                                                         ├─ build_alerts()/dispatch() ─> Slack / email / log
                                                         └─ dashboard.html (self-contained, with what-if)
```
## Data dictionary
- sku_master(sku, name, supplier, base_daily)
- inventory_hourly(ts, sku, stock, demand, unmet): stock after demand; unmet = lost demand
- shipments(shipment_id, sku, supplier, order_ts, promised_days, actual_days, qty, delivered, eta_days, delay_days, on_time): on_time = delay <= 0.5 day; undelivered rows are in transit
- sku_status(sku, ..., fc_daily, cover_days, wait_days, in_transit, mape, status)

## Key definitions
- Stock-out rate = share of SKU-hours with zero stock. Days of inventory = current stock / mean daily demand (last 14d).
- Cover days = days until cumulative forecast demand exhausts current stock. Wait = ETA of open order, else supplier lead time.
- Status: Critical if cover < wait; Watch if cover < wait + 2; else OK. What-if adds the delay to the chosen supplier's wait.
- Alert thresholds (pipeline.TH): stock-out > 2%, recent on-time < 85%, demand z > 3, delay z > 2.5, any Critical SKU.

## Limits and next steps
Prophet is fit on only 45 days, so it can over-read short spikes (SKU03's forecast is inflated and has the worst MAPE). Replace simulated feeds with a real ERP/WMS stream, add promotions and holidays as Prophet regressors, and schedule model retraining separately from hourly refreshes.
