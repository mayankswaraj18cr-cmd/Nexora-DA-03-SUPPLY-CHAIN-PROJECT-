# 10-minute presentation outline
1. Problem (1 min): stock-outs and late suppliers are found after sales are lost.
2. Design (2 min): architecture diagram; Postgres, hourly Airflow, analytics, alerts, dashboards.
3. Live demo (3.5 min): Overview KPIs, Inventory critical SKUs, Suppliers (S4 lead time), Forecast, Anomalies, What-if (S4 delayed 7 days), Alerts.
4. Challenges (1 min): making the simulator produce verifiable incidents; Prophet on short history; defining cover vs in-transit orders.
5. Results (1.5 min): MAPE, anomalies found, Critical SKUs flagged before stock-out, tests passing.
6. Next steps (1 min): real data feed, promotions as regressors, retraining schedule, Superset in production.
