"""Hourly Airflow DAG: refresh feeds -> load Postgres -> KPIs/anomalies/forecast/alerts -> rebuild dashboard."""
import sys
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
sys.path.insert(0, "/opt/airflow/project")
import pipeline, load_to_postgres

def generate_feed():
    inv, ship, sku = pipeline.simulate()
    inv.to_csv(f"{pipeline.ROOT}/data/inventory_hourly.csv", index=False)
    ship.to_csv(f"{pipeline.ROOT}/data/shipments.csv", index=False)
    sku.to_csv(f"{pipeline.ROOT}/data/sku_master.csv", index=False)

with DAG("control_tower_hourly", start_date=datetime(2026, 10, 20), schedule="@hourly", catchup=False,
         default_args=dict(retries=2, retry_delay=timedelta(minutes=5)), tags=["DA-03"]) as dag:
    a = PythonOperator(task_id="generate_feed", python_callable=generate_feed)
    b = PythonOperator(task_id="load_postgres", python_callable=load_to_postgres.load)
    c = PythonOperator(task_id="analyze_alert_publish", python_callable=pipeline.run_all)  # KPIs, anomalies, Prophet, alerts, dashboard
    a >> b >> c
