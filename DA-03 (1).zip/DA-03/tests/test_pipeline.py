import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest, pipeline as p

@pytest.fixture(scope="module")
def sim():
    return p.simulate()

def test_deterministic_and_shape(sim):
    inv, ship, sku = sim
    assert len(inv) == 12 * p.DAYS * 24 and len(sku) == 12
    assert inv.equals(p.simulate()[0])

def test_stock_never_negative_and_unmet_consistent(sim):
    inv, _, _ = sim
    assert (inv.stock >= 0).all() and (inv.unmet >= 0).all() and (inv.unmet <= inv.demand).all()

def test_on_time_definition(sim):
    _, ship, _ = sim
    assert ((ship.delay_days <= 0.5).astype(int) == ship.on_time).all()

def test_kpis_in_range(sim):
    k = p.kpis(*sim)
    assert 0 <= k["stockout_pct_7d"] <= 100 and 0 <= k["on_time_pct"] <= 100 and k["avg_lead_days"] > 0

def test_detects_injected_demand_spike(sim):
    an = p.anomalies(*sim)
    assert any(s["sku"] == "SKU03" for s in an["demand_spikes"])

def test_detects_injected_supplier_delay(sim):
    an = p.anomalies(*sim)
    assert any(d["supplier"] == "S4" for d in an["delay_outliers"])

def test_status_and_whatif_logic():
    assert p.status(2, 3) == "Critical" and p.status(4, 3) == "Watch" and p.status(9, 3) == "OK"
    skus = [dict(sku="A", supplier="S1", cover_days=8, wait_days=3, fc_daily=10, status="OK"),
            dict(sku="B", supplier="S2", cover_days=8, wait_days=3, fc_daily=10, status="OK")]
    r = {x["sku"]: x for x in p.whatif(skus, "S1", 7)}
    assert r["A"]["after"] == "Critical" and r["A"]["lost_units"] == 20 and r["B"]["after"] == "OK"

def test_forecast_accuracy_and_alerts(sim):
    skus, fc = p.forecast(*sim)
    assert sum(s["mape"] for s in skus) / len(skus) < 25
    assert all(len(v["fc"]["yhat"]) == p.HORIZON for v in fc.values())
    al = p.build_alerts(p.kpis(*sim), skus, p.anomalies(*sim))
    assert any(a["rule"] == "stock_cover" for a in al)
