"""Builds DA-03_Research_Paper_and_Source.pdf; all numbers come from the live pipeline run."""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.lib.units import mm
import paperkit as k, pipeline as p

R = p.ROOT
d = p.run_all()
K, an, skus, fc, al = d["kpis"], d["an"], d["skus"], d["fc"], d["alerts"]
inv, ship, _ = p.simulate()
os.makedirs("/tmp/fig3", exist_ok=True)

T = K["trend"]; x = [s[5:] for s in T["dates"]]
fig, ax = plt.subplots(1, 2, figsize=(9, 3.1))
ax[0].bar(range(len(x)), T["stockout_pct"], color="#c93a3a"); ax[0].set_title("Daily stock-out rate (% of SKU-hours at zero stock)", fontsize=8.5)
ax[0].set_xticks(range(0, len(x), 5)); ax[0].set_xticklabels(x[::5], fontsize=7)
g = fc["SKU03"]; hd, fd = g["hist"]["dates"], g["fc"]["dates"]
ax[1].plot(range(len(hd)), g["hist"]["y"], color="#1a3c6e", label="Actual daily demand")
fx = range(len(hd), len(hd) + len(fd)); ax[1].plot(fx, g["fc"]["yhat"], color="#e0a030", label="Prophet forecast"); ax[1].fill_between(fx, g["fc"]["lo"], g["fc"]["hi"], color="#e0a030", alpha=.2)
ax[1].set_title("SKU03 (Detergent): demand spike and forecast", fontsize=8.5); ax[1].legend(fontsize=7)
for a in ax: a.tick_params(labelsize=7)
plt.tight_layout(); plt.savefig("/tmp/fig3/f1.png", dpi=170); plt.close()

crit = [s for s in skus if s["status"] == "Critical"]; watch = [s for s in skus if s["status"] == "Watch"]
base = p.whatif(skus, "S1", 0); base_c = sum(r["after"] == "Critical" for r in base); base_u = sum(r["lost_units"] for r in base)
wrows = []
for sid in p.SUP:
    r = p.whatif(skus, sid, 7); c = sum(x["after"] == "Critical" for x in r); u = sum(x["lost_units"] for x in r)
    wrows.append([f"{sid} {p.SUP[sid][0]}", c, f"{u:,}", f"{u - base_u:+,}"])
dl = ship[ship.delivered == 1]
sections = [
 ("1. Introduction", [
  "Retail supply chains lose sales in two ways that are often noticed only afterwards: a product runs out because demand rose faster than planned, or a supplier delivers late and the replenishment never arrives in time. A control tower is a monitoring layer that brings inventory, shipment and supplier data together, computes a small set of indicators, and raises an alert while there is still time to act. This paper describes a working control tower built on simulated hourly feeds. It computes four service and inventory KPIs, detects demand and supplier anomalies with two statistical methods, forecasts demand with Prophet, converts the forecast into a stock-cover risk status for every SKU, lets a manager test supplier-delay scenarios, and dispatches alerts.",
  "The contributions are: (i) a simulator whose injected incidents let detection be verified rather than assumed; (ii) a cover-versus-replenishment-wait risk rule that accounts for orders already in transit; (iii) an interactive what-if analysis of supplier delay; and (iv) an hourly orchestration design (Airflow, PostgreSQL, Superset) with an offline dashboard that mirrors the same logic."]),
 ("2. Background and Related Work", [
  "Classical inventory theory balances ordering and holding cost to choose order quantities [1] and uses reorder points set from lead-time demand plus a safety allowance; this system uses a reorder-point policy to generate realistic stock trajectories. For demand forecasting it uses Prophet, an additive model with trend and seasonal components designed to be robust and easy to configure [2]. Forecast accuracy is reported as mean absolute percentage error (MAPE), whose weaknesses with small actuals are well documented [3]; the denominator is therefore floored at one unit here. For supplier anomalies it combines a z-score rule with Isolation Forest, which isolates unusual points by random partitioning and needs no labelled anomalies [4]."]),
 ("3. System Design", [
  "Data flow: hourly feeds are written as CSV (inventory_hourly, shipments, sku_master), loaded into PostgreSQL, analysed, and published. An Airflow DAG (control_tower_hourly, schedule @hourly) runs three tasks in sequence: generate_feed, load_postgres, analyze_alert_publish. The last task computes KPIs, anomalies, forecasts and statuses, evaluates alert rules, dispatches alerts to Slack and/or email, and rebuilds the self-contained dashboard.html. SQL views (v_stockout_daily, v_supplier_perf) are provided for Superset charts.",
  ("table", [["Table", "Main columns"], ["sku_master", "sku, name, supplier, base_daily"], ["inventory_hourly", "ts, sku, stock, demand, unmet"],
             ["shipments", "shipment_id, sku, supplier, order_ts, promised_days, actual_days, qty, delivered, eta_days, delay_days, on_time"],
             ["sku_status", "sku, supplier, stock, fc_daily, cover_days, wait_days, in_transit, mape, status"]], "Table 1. Data model.", [34 * mm, 140 * mm])]),
 ("4. Methods", [
  ("h2", "4.1 Simulation of hourly feeds"),
  f"The simulator covers {p.DAYS} days from 1 September 2026 for 12 SKUs and 6 suppliers (nominal lead times 3, 5, 4, 4, 2 and 6 days), with a fixed seed. Each SKU has a base daily demand drawn uniformly from 40 to 199 units. Hourly demand is Poisson with mean",
  ("eq", "lambda = base/24 * hourly_profile(h) * (1.25 if weekend) * (2.5 for SKU03 in the last 72 hours)"),
  "where the hourly profile is low overnight and peaks in daytime (normalised to mean 1). Each SKU follows a reorder-point policy: an order of eight days of demand is placed when stock falls to (lead time + 2) days of demand and no order is open. The realised lead time is the nominal lead time plus Gaussian noise (standard deviation 0.5 day), plus an extra 5 days for supplier S4 on orders placed in the last 480 hours. Two incidents are therefore built in: a demand spike on SKU03 and a delivery-delay incident at supplier S4 (Delta Traders).",
  ("h2", "4.2 KPIs"),
  ("bul", ["<b>Stock-out rate:</b> share of SKU-hours with zero stock (reported for the last 7 days and overall).",
           "<b>On-time delivery:</b> share of delivered shipments with delay of at most 0.5 day versus the promised lead time; also reported for orders in the last 20 days.",
           "<b>Supplier lead time:</b> mean realised lead time per supplier against the promised value.",
           "<b>Days of inventory:</b> current stock divided by mean daily demand of the last 14 days."]),
  ("h2", "4.3 Anomaly detection"),
  "Demand spikes: for each SKU and day, a rolling z-score compares the day with the previous 14 days, z = (x - mean) / std, and flags z above 3. Supplier delays: the delay (actual minus promised days) of each delivered shipment is standardised across all shipments and flagged above 2.5; in addition an Isolation Forest (contamination 0.08) on delay and order size flags shipments with delay above one day. The method that fired is recorded for each flag.",
  ("h2", "4.4 Forecast, cover and risk status"),
  "For each SKU a Prophet model with weekly seasonality (daily and yearly seasonality off) is fitted to daily demand and used for a 14-day forecast. Accuracy is measured by a backtest: fit on the first 38 days, predict the last 7, compute MAPE. Stock cover is the number of days until cumulative forecast demand exhausts current stock. The replenishment wait is the ETA of the open order if one is in transit, otherwise the supplier lead time. Status is then",
  ("eq", "Critical if cover < wait;  Watch if cover < wait + 2;  OK otherwise"),
  "The what-if analysis adds a chosen delay to the wait of every SKU of one supplier and recomputes status and units at risk, where units at risk = max(0, wait - cover) * forecast daily demand. The same logic is implemented in Python (tested) and in the dashboard's JavaScript.",
  ("h2", "4.5 Alerts"),
  "Rules: 7-day stock-out rate above 2%; recent on-time delivery below 85%; any Critical SKU; any supplier with abnormal delay flags; and demand spikes in the last three days (informational). Alerts are posted to a Slack webhook and/or sent by SMTP when credentials are configured, otherwise written to a log as a dry run."]),
 ("5. Results", [
  f"The simulation produced {len(inv):,} hourly inventory records and {len(ship)} shipments, of which {len(dl)} were delivered within the horizon.",
  ("table", [["KPI", "Value"], ["Stock-out rate, last 7 days", f"{K['stockout_pct_7d']}%"], ["Stock-out rate, whole period", f"{K['stockout_pct_all']}%"], ["On-time delivery (all delivered)", f"{K['on_time_pct']}%"],
             ["On-time delivery (orders in last 20 days)", f"{K['on_time_pct_recent']}%"], ["Average supplier lead time", f"{K['avg_lead_days']} days"], ["Average days of inventory", f"{K['avg_days_of_inventory']} days"], ["Mean forecast MAPE (7-day backtest)", f"{d['mape']}%"]], "Table 2. Headline KPIs.", [90 * mm, 50 * mm]),
  "The recent stock-out rate is far above the whole-period rate, which shows that the problems are concentrated at the end of the horizon where the incidents were injected.",
  ("table", [["Supplier", "Name", "Promised (d)", "Avg lead (d)", "On-time %", "Delivered"]] + [[s["id"], s["name"], s["promised"], s["avg_lead"], s["on_time_pct"], s["shipments"]] for s in K["suppliers"]], "Table 3. Supplier performance.", [18 * mm, 45 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm]),
  f"Supplier S4 has the longest gap between promised and realised lead time and the lowest on-time rate, which is the injected incident. The anomaly stage flagged {len(an['delay_outliers'])} delivery delay(s) (suppliers: {', '.join(sorted({a['supplier'] for a in an['delay_outliers']}))}) and {len(an['demand_spikes'])} demand spike day(s), including SKU03 on " + ", ".join(sorted({a['date'] for a in an['demand_spikes'] if a['sku'] == 'SKU03'})) + ", the injected spike. Other flags are natural variation and are an expected false-positive cost of a z-score rule at this threshold.",
  ("table", [["SKU", "Item", "Sup.", "Stock", "Fcst/day", "Cover (d)", "Wait (d)", "MAPE %", "Status"]] + [[s["sku"], s["name"], s["supplier"], s["stock"], s["fc_daily"], s["cover_days"], s["wait_days"], s["mape"], s["status"]] for s in skus], "Table 4. SKU status at the end of the horizon.", [16 * mm, 32 * mm, 13 * mm, 17 * mm, 20 * mm, 20 * mm, 18 * mm, 18 * mm, 20 * mm]),
  f"{len(crit)} SKU(s) are Critical ({', '.join(s['sku'] for s in crit) or 'none'}) and {len(watch)} on Watch. Both critical SKUs belong to the delayed supplier S4: their open orders are late, so cover is shorter than the wait. The system raised {len(al)} alerts, listed in Table 5.",
  ("table", [["Severity", "Rule", "Message"]] + [[a["severity"], a["rule"], a["message"]] for a in al], "Table 5. Alerts raised.", [20 * mm, 30 * mm, 124 * mm]),
  f"What-if: with no extra delay, {base_c} SKUs are Critical and about {base_u:,} units are at risk over the horizon. Table 6 adds a further 7-day delay to one supplier at a time. A delay at a supplier whose SKUs are already critical (S4) increases the units at risk but cannot raise the critical count, whereas a delay at a healthier supplier can turn its currently covered SKUs critical. Ranking suppliers by the extra units at risk shows where a delay would cost the most sales.",
  ("table", [["Supplier delayed 7 more days", "Critical SKUs", "Units at risk", "Change vs baseline"]] + wrows, "Table 6. What-if: effect of a 7-day delay by supplier.", [62 * mm, 32 * mm, 36 * mm, 44 * mm]),
  ("fig", "/tmp/fig3/f1.png", "Figure 1. Daily stock-out rate (left) and SKU03 demand with its 14-day Prophet forecast and interval (right).", 170, 0.345)]),
 ("6. Verification", [
  "Eight automated tests (pytest) check: determinism and shape of the simulation; stock never negative and unmet demand never above demand; the on-time definition; KPI ranges; detection of the injected SKU03 spike and the injected S4 delay incident; the status and what-if rules on a hand-computed case; and forecast quality (mean MAPE below 25%, 14-day horizon) together with the presence of a stock-cover alert. All eight pass. The dashboard JavaScript was executed against a stubbed browser environment to catch runtime errors. The Docker Compose stack, Airflow DAG execution, PostgreSQL loading and live Slack or email delivery were written but could not be executed in the build environment and are marked as unverified in the README."]),
 ("7. Discussion and Limitations", [
  ("bul", ["<b>Simulated data.</b> Feeds are synthetic and incidents are known by construction, so detection results show that the logic works, not how it performs on real noise.",
           "<b>Short history for Prophet.</b> Only 45 days are available, so the model has no yearly seasonality and reacts strongly to recent spikes. The SKU03 forecast is inflated by the injected spike and has the worst backtest error (Figure 1, Table 4); a real system should treat flagged spikes as outliers or regressors before fitting.",
           "<b>Threshold sensitivity.</b> The z-score thresholds, the 0.5-day on-time tolerance, the 2-day Watch margin and the alert limits are illustrative and need tuning against business cost.",
           "<b>Simplifications.</b> One warehouse, no substitution between SKUs, no capacity limits, no promotions, and lost sales are not backordered.",
           "<b>Unverified infrastructure.</b> See Section 6."]),
  ]),
 ("8. Future Work", [
  "Next steps are connecting real warehouse and ERP feeds, adding promotions and holidays as Prophet regressors, treating detected anomalies as outliers before forecasting, scheduling model retraining separately from the hourly refresh, adding safety-stock optimisation and supplier scorecards, and validating the full container stack end to end."]),
]
refs = ["[1] Harris, F. W. (1913). How many parts to make at once. Factory, The Magazine of Management, 10(2), 135-136.",
        "[2] Taylor, S. J., and Letham, B. (2018). Forecasting at scale. The American Statistician, 72(1), 37-45.",
        "[3] Hyndman, R. J., and Koehler, A. B. (2006). Another look at measures of forecast accuracy. International Journal of Forecasting, 22(4), 679-688.",
        "[4] Liu, F. T., Ting, K. M., and Zhou, Z.-H. (2008). Isolation forest. Proceedings of the 8th IEEE International Conference on Data Mining, 413-422."]
summary = ["<b>Problem:</b> stock-outs and late suppliers are usually discovered after sales are lost.",
           "<b>Approach:</b> hourly simulated feeds, four KPIs, z-score and Isolation Forest anomaly detection, Prophet forecasts converted into stock-cover risk status, a supplier-delay what-if tool, Slack/email alerts, and an Airflow, PostgreSQL and Superset design with an offline HTML dashboard.",
           f"<b>Results:</b> 7-day stock-out rate {K['stockout_pct_7d']}%; on-time delivery {K['on_time_pct']}%; mean forecast MAPE {d['mape']}%; both injected incidents (SKU03 demand spike, supplier S4 delays) detected; {len(crit)} critical SKUs and {len(al)} alerts; 8 of 8 tests pass.",
           "<b>Caveat:</b> data are simulated and the Docker, Airflow, PostgreSQL and live-alert components were not executed in the build environment."]
k.build(f"{R}/DA-03_Research_Paper_and_Source.pdf", "A Supply-Chain Control Tower for Early Warning of Stock-outs and Supplier Delays", "Hourly feeds, anomaly detection, Prophet forecasts and cover-based risk alerts (DA-03)",
        "DA-03 Retail and Supply Chain Control Tower", summary, sections, refs,
        "You cannot manage what you only see after the sale is lost; the work is to see it hours before.",
        [("pipeline.py", f"{R}/pipeline.py"), ("dags/control_tower_dag.py", f"{R}/dags/control_tower_dag.py"), ("load_to_postgres.py", f"{R}/load_to_postgres.py"), ("schema.sql", f"{R}/schema.sql"),
         ("docker-compose.yml", f"{R}/docker-compose.yml"), ("tests/test_pipeline.py", f"{R}/tests/test_pipeline.py"), ("build_paper.py", f"{R}/build_paper.py")])
print("pdf built")
