"""DA-03 Retail & Supply Chain Control Tower.
Simulates hourly inventory/shipment/supplier feeds, computes KPIs, detects anomalies
(z-score + Isolation Forest), forecasts demand (Prophet), raises alerts and builds dashboard.html.
Run: python pipeline.py"""
import json, logging, os, smtplib, urllib.request, warnings
from email.message import EmailMessage
import numpy as np, pandas as pd
from sklearn.ensemble import IsolationForest

warnings.filterwarnings("ignore")
for n in ("cmdstanpy", "prophet"):
    logging.getLogger(n).setLevel(logging.ERROR)
ROOT = os.path.dirname(os.path.abspath(__file__))
START, DAYS, HORIZON = pd.Timestamp("2026-09-01"), 45, 14
SUP = {"S1": ("Apex Foods", 3), "S2": ("BlueLine Home", 5), "S3": ("CityCare", 4),
       "S4": ("Delta Traders", 4), "S5": ("EastGate FMCG", 2), "S6": ("Fortis Stationers", 6)}
NAMES = ["Rice 5kg", "Cooking Oil 1L", "Detergent", "Shampoo", "Toothpaste", "Biscuits",
         "Tea 500g", "Notebook", "Battery AA", "LED Bulb", "Soap", "Noodles"]
TH = dict(stockout_pct=2.0, on_time_pct=85.0, z=3.0, delay_z=2.5)


def simulate(seed=11):
    rng = np.random.default_rng(seed)
    hf = np.array([0.3 + (8 <= h <= 21) * (0.9 + 0.5 * np.sin(np.pi * (h - 8) / 13)) for h in range(24)])
    hf /= hf.mean()
    skus = [(f"SKU{i:02d}", NAMES[i - 1], f"S{(i - 1) % 6 + 1}", int(rng.integers(40, 200))) for i in range(1, 13)]
    hours, inv, ships, sid = DAYS * 24, [], [], 0
    for sku, _, sup, base in skus:
        lead, stock, op = SUP[sup][1], base * (SUP[sup][1] + 4), None
        for t in range(hours):
            ts = START + pd.Timedelta(hours=t)
            if op and t >= op["arr"]:
                stock += op["qty"]; op = None
            lam = base / 24 * hf[ts.hour] * (1.25 if ts.dayofweek >= 5 else 1) * (2.5 if sku == "SKU03" and t >= hours - 72 else 1)
            d = int(rng.poisson(lam)); sold = min(stock, d); stock -= sold
            inv.append((ts, sku, int(stock), d, d - sold))
            if op is None and stock <= base * (lead + 2):
                act = max(1.0, lead + rng.normal(0, 0.5) + (5 if sup == "S4" and t >= hours - 480 else 0))
                arr = t + int(act * 24); sid += 1
                op = dict(arr=arr, qty=base * 8)
                ships.append(dict(shipment_id=f"SH{sid:04d}", sku=sku, supplier=sup, order_ts=ts, promised_days=lead,
                                  actual_days=round(act, 2), qty=base * 8, delivered=int(arr < hours),
                                  eta_days=round(max(0, (arr - hours) / 24), 2)))
    sku_df = pd.DataFrame(skus, columns=["sku", "name", "supplier", "base_daily"])
    ship = pd.DataFrame(ships)
    ship["delay_days"] = (ship.actual_days - ship.promised_days).round(2)
    ship["on_time"] = (ship.delay_days <= 0.5).astype(int)
    return pd.DataFrame(inv, columns=["ts", "sku", "stock", "demand", "unmet"]), ship, sku_df


def daily_demand(inv):
    d = inv.assign(date=inv.ts.dt.normalize()).groupby(["sku", "date"]).demand.sum().reset_index()
    return d


def kpis(inv, ship, sku_df):
    last7 = inv[inv.ts >= inv.ts.max() - pd.Timedelta(days=7)]
    dl = ship[ship.delivered == 1]
    rec = dl[dl.order_ts >= ship.order_ts.max() - pd.Timedelta(days=20)]
    dd = daily_demand(inv)
    doi = {}
    for s in sku_df.sku:
        cur = int(inv[inv.sku == s].stock.iloc[-1]); avg = dd[dd.sku == s].demand.tail(14).mean()
        doi[s] = round(cur / avg, 1)
    sup = []
    for k, (nm, lead) in SUP.items():
        x = dl[dl.supplier == k]
        sup.append(dict(id=k, name=nm, promised=lead, avg_lead=round(float(x.actual_days.mean()), 2) if len(x) else None,
                        on_time_pct=round(float(x.on_time.mean() * 100), 1) if len(x) else None, shipments=int(len(x))))
    trend = inv.assign(date=inv.ts.dt.strftime("%Y-%m-%d")).groupby("date").apply(
        lambda g: pd.Series(dict(stockout_pct=round((g.stock == 0).mean() * 100, 2), demand=int(g.demand.sum()))))
    return dict(stockout_pct_7d=round(float((last7.stock == 0).mean() * 100), 2),
                stockout_pct_all=round(float((inv.stock == 0).mean() * 100), 2),
                on_time_pct=round(float(dl.on_time.mean() * 100), 1),
                on_time_pct_recent=round(float(rec.on_time.mean() * 100), 1),
                avg_lead_days=round(float(dl.actual_days.mean()), 2),
                avg_days_of_inventory=round(float(np.mean(list(doi.values()))), 1),
                days_of_inventory=doi, suppliers=sup,
                trend=dict(dates=list(trend.index), stockout_pct=trend.stockout_pct.tolist(), demand=trend.demand.tolist()))


def anomalies(inv, ship, sku_df):
    dd, spikes = daily_demand(inv), []
    for s, g in dd.groupby("sku"):
        v = g.demand.values
        for i in range(14, len(v)):
            w = v[i - 14:i]; z = (v[i] - w.mean()) / (w.std() or 1)
            if z > TH["z"]:
                spikes.append(dict(sku=s, date=str(g.date.iloc[i].date()), demand=int(v[i]), z=round(float(z), 1)))
    dl = ship[ship.delivered == 1].copy()
    dl["z"] = (dl.delay_days - dl.delay_days.mean()) / dl.delay_days.std()
    base = sku_df.set_index("sku").base_daily
    feats = np.c_[dl.delay_days, dl.qty / dl.sku.map(base)]
    dl["iso"] = IsolationForest(contamination=0.08, random_state=0).fit_predict(feats) == -1
    out = dl[(dl.z > TH["delay_z"]) | (dl.iso & (dl.delay_days > 1))]
    delays = [dict(shipment=r.shipment_id, supplier=r.supplier, sku=r.sku, delay_days=float(r.delay_days), z=round(float(r.z), 1),
                   method="z-score + IsolationForest" if (r.z > TH["delay_z"] and r.iso) else ("z-score" if r.z > TH["delay_z"] else "IsolationForest"))
              for r in out.itertuples()]
    return dict(demand_spikes=sorted(spikes, key=lambda x: -x["z"]), delay_outliers=delays)


def forecast(inv, ship, sku_df):
    from prophet import Prophet
    dd, res, rows = daily_demand(inv), {}, []
    openq = ship[ship.delivered == 0].set_index("sku").eta_days.to_dict()
    for r in sku_df.itertuples():
        g = dd[dd.sku == r.sku].rename(columns={"date": "ds", "demand": "y"})[["ds", "y"]]
        mk = lambda d: Prophet(weekly_seasonality=True, daily_seasonality=False, yearly_seasonality=False).fit(d)
        tr, te = g.iloc[:-7], g.iloc[-7:]
        p = mk(tr).predict(pd.DataFrame({"ds": te.ds})).yhat.clip(lower=0).values
        mape = float(np.mean(np.abs(te.y.values - p) / np.maximum(te.y.values, 1)) * 100)
        m = mk(g); f = m.predict(m.make_future_dataframe(HORIZON)).tail(HORIZON)
        fc = f.yhat.clip(lower=0).values
        stock = int(inv[inv.sku == r.sku].stock.iloc[-1]); cum = np.cumsum(fc)
        cover = float(14 + (stock - cum[-1]) / fc.mean()) if stock > cum[-1] else float(np.interp(stock, np.r_[0, cum], np.arange(HORIZON + 1)))
        lead = SUP[r.supplier][1]; wait = float(openq.get(r.sku, lead))
        res[r.sku] = dict(hist=dict(dates=[str(d.date()) for d in g.ds], y=g.y.tolist()),
                          fc=dict(dates=[str(d.date()) for d in f.ds], yhat=[round(float(x), 1) for x in fc],
                                  lo=[round(float(x), 1) for x in f.yhat_lower.clip(lower=0)], hi=[round(float(x), 1) for x in f.yhat_upper]))
        rows.append(dict(sku=r.sku, name=r.name, supplier=r.supplier, stock=stock, fc_daily=round(float(fc.mean()), 1),
                         cover_days=round(cover, 1), lead_days=lead, wait_days=round(wait, 1), in_transit=int(r.sku in openq),
                         mape=round(mape, 1)))
    for x in rows: x["status"] = status(x["cover_days"], x["wait_days"])
    return rows, res


def status(cover, wait):
    return "Critical" if cover < wait else "Watch" if cover < wait + 2 else "OK"


def whatif(skus, supplier, delay):
    out = []
    for s in skus:
        w = s["wait_days"] + (delay if s["supplier"] == supplier else 0)
        out.append(dict(sku=s["sku"], supplier=s["supplier"], before=s["status"], after=status(s["cover_days"], w),
                        lost_units=round(max(0.0, w - s["cover_days"]) * s["fc_daily"])))
    return out


def build_alerts(k, skus, an):
    a = []
    if k["stockout_pct_7d"] > TH["stockout_pct"]:
        a.append(dict(severity="warning", rule="stockout_rate", message=f"7-day stock-out rate {k['stockout_pct_7d']}% exceeds {TH['stockout_pct']}%"))
    if k["on_time_pct_recent"] < TH["on_time_pct"]:
        a.append(dict(severity="warning", rule="on_time_delivery", message=f"Recent on-time delivery {k['on_time_pct_recent']}% below {TH['on_time_pct']}%"))
    for s in skus:
        if s["status"] == "Critical":
            a.append(dict(severity="critical", rule="stock_cover", message=f"{s['sku']} {s['name']}: cover {s['cover_days']}d < replenishment wait {s['wait_days']}d (supplier {s['supplier']})"))
    for sp in sorted({d["supplier"] for d in an["delay_outliers"]}):
        n = sum(d["supplier"] == sp for d in an["delay_outliers"])
        a.append(dict(severity="warning", rule="supplier_delay", message=f"Supplier {sp} ({SUP[sp][0]}): {n} abnormal delivery delay(s)"))
    for d in [x for x in an["demand_spikes"] if x["date"] >= str((START + pd.Timedelta(days=DAYS - 3)).date())][:3]:
        a.append(dict(severity="info", rule="demand_spike", message=f"{d['sku']} demand spike on {d['date']} ({d['demand']} units, z={d['z']})"))
    return a


def dispatch(alerts):
    """Slack (SLACK_WEBHOOK_URL) and/or email (SMTP_HOST, ALERT_TO); otherwise dry-run to alerts.log."""
    text = "\n".join(f"[{x['severity'].upper()}] {x['message']}" for x in alerts) or "No alerts"
    sent = []
    if os.getenv("SLACK_WEBHOOK_URL"):
        urllib.request.urlopen(urllib.request.Request(os.environ["SLACK_WEBHOOK_URL"], json.dumps({"text": text}).encode(), {"Content-Type": "application/json"}))
        sent.append("slack")
    if os.getenv("SMTP_HOST") and os.getenv("ALERT_TO"):
        m = EmailMessage(); m["Subject"] = "Control Tower alerts"; m["From"] = os.getenv("ALERT_FROM", "tower@example.com"); m["To"] = os.environ["ALERT_TO"]; m.set_content(text)
        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.getenv("SMTP_PORT", 587))) as s:
            s.starttls()
            if os.getenv("SMTP_USER"): s.login(os.environ["SMTP_USER"], os.environ["SMTP_PASS"])
            s.send_message(m)
        sent.append("email")
    if not sent:
        open(f"{ROOT}/data/alerts.log", "w").write(text + "\n"); sent.append("log (dry-run)")
    return sent


def run_all():
    inv, ship, sku_df = simulate()
    inv.to_csv(f"{ROOT}/data/inventory_hourly.csv", index=False); ship.to_csv(f"{ROOT}/data/shipments.csv", index=False); sku_df.to_csv(f"{ROOT}/data/sku_master.csv", index=False)
    k, an = kpis(inv, ship, sku_df), anomalies(inv, ship, sku_df)
    skus, fc = forecast(inv, ship, sku_df)
    al = build_alerts(k, skus, an)
    pd.DataFrame(skus).to_csv(f"{ROOT}/data/sku_status.csv", index=False)
    json.dump(al, open(f"{ROOT}/data/alerts.json", "w"), indent=1)
    mape = round(float(np.mean([s["mape"] for s in skus])), 1)
    json.dump(dict(kpis={x: k[x] for x in k if x not in ("trend", "suppliers", "days_of_inventory")}, mean_forecast_mape_pct=mape,
                   anomalies=dict(demand_spikes=len(an["demand_spikes"]), delay_outliers=len(an["delay_outliers"])), alerts=len(al),
                   statuses={s: sum(x["status"] == s for x in skus) for s in ("Critical", "Watch", "OK")}), open(f"{ROOT}/docs/metrics.json", "w"), indent=1)
    data = dict(kpis=k, an=an, skus=skus, fc=fc, alerts=al, sup=SUP, mape=mape, sent=dispatch(al))
    html = open(f"{ROOT}/dashboard_template.html", encoding="utf-8").read().replace("__DATA__", json.dumps(data, default=str))
    open(f"{ROOT}/dashboard.html", "w", encoding="utf-8").write(html)
    return data


if __name__ == "__main__":
    d = run_all()
    print("KPIs", {x: d["kpis"][x] for x in ("stockout_pct_7d", "on_time_pct", "on_time_pct_recent", "avg_lead_days")}, "| MAPE", d["mape"],
          "| alerts", len(d["alerts"]), "| spikes", len(d["an"]["demand_spikes"]), "| delays", len(d["an"]["delay_outliers"]))
